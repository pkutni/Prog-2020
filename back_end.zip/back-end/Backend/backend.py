from config import *
from models import Bebeida

@app.route("/") #pagina inicial
def inicar():
    return 'olá! Bem vindo ao codigo do Pedro H. Kutni. '+\
        '<a href="/listar_bebida">Ao clickar aqui será listada as bebidas já cadastradas no BD</a>'

@app.route("/listar_bebida")
def listar_bebida():
    bebida = db.session.query(Bebeida).all()
    bebida_lista = [ bla.json() for bla in bebida ]
    return jsonify(bebida_lista) 

app.run(debug=True)