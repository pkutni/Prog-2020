from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)

#diretorio do arquivo
path = os.path.dirname(os.path.abspath(__file__))
arquivobd = os.path.join(path, 'time.db')

#config do bd
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///"+arquivobd
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False #sem avisos
db = SQLAlchemy(app)