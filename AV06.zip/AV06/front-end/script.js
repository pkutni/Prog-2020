$(function() { 
    
    function exibir_bebidas() {
        $.ajax({
            url: 'http://localhost:5000/listar_bebidas',
            method: 'GET',
            dataType: 'json', 
            success: listarBebidas, 
            error: function() {
                alert(" E R R O ");
            }
        });

        function listarBebidas(bebidas) {
            $("#corpoTabelaBebida").empty();
            mostrarConteudo("bebidas")
            for (bebida of bebidas) { 
                novaLinha = `<tr id="linha_${bebida.id}"> 
                            <td>${bebida.nome_bebida}</td> 
                            <td>${bebida.tipo_bebida}</td> 
                            <td>${bebida.preco_bebida}</td> 
                            <td><a href=# id="${bebida.id}" class="excluir_bebida">
                            <p class="badge badge-danger">Excluir</p> </a> </td>
                          </tr>`;
                $('#tabelaBebida').append(novaLinha); 
            }
        }
    }

    function exibir_vendedores() {
        $.ajax({
            url: 'http://localhost:5000/listar_vendedores',
            method: 'GET',
            dataType: 'json', 
            success: listarVendedor, 
            error: function() {
                alert(" E R R O ");
            }
        });

        function listarVendedor(vendedores) {
            $("#corpoTabelaVendedor").empty();
            mostrarConteudo("vendedores")
            for (vendedor of vendedores) { 
                novaLinha = `<tr id="linha_${vendedor.id}"> 
                            <td>${vendedor.nome}</td> 
                            <td>${vendedor.telefone}</td> 
                          </tr>`;
                $('#tabelaVendedor').append(novaLinha); 
            }
        }
    }

    function exibir_setores() {
        $.ajax({
            url: 'http://localhost:5000/listar_setores',
            method: 'GET',
            dataType: 'json', 
            success: listarsetors, 
            error: function() {
                alert(" E R R O ");
            }
        });

        function listarsetors(setores) {
            $("#corpoTabelaSetors").empty();
            mostrarConteudo("setores")
            for (setor of setores) { 
                novaLinha = `<tr id="linha_${setor.id}"> 
                            <td>${setor.nome}</td> 
                            <td>${setor.funcionamento}</td> 
                            <td>${setor.bebida.nome_bebida}</td> 
                            <td>${setor.bebida.tipo_bebida}</td> 
                            <td>${setor.bebida.preco_bebida}</td> 
                            <td>${setor.vendedor.nome}</td> 
                            <td>${setor.vendedor.telefone}</td> 
                          </tr>`;
                $('#tabelasetors').append(novaLinha); 
            }
        }
    }

    function mostrarConteudo(identificador) {
        $("#bebidas").addClass('d-none');
        $("#vendedores").addClass('d-none');
        $("#setores").addClass('d-none');
        $("#conteudoInicial").addClass('d-none');
        $("#"+identificador).removeClass('d-none');      
    }

    $(document).on("click", "#linklistarBebidas", function() {
        exibir_bebidas();
    });

    $(document).on("click", "#linklistarVendedor", function() {
        exibir_vendedores();
    });

    $(document).on("click", "#linkListarsetors", function() {
        exibir_setores();
    });
    
    $(document).on("click", "#linkInicio", function() {
        mostrarConteudo("conteudoInicial");
    });

    $(document).on("click", "#btIncluirBebida", function() {
        nome_bebida = $("#campoNomeBebida").val();
        tipo_bebida = $("#campoTipoBebida").val();
        preco_bebida = $("#campoPreco").val();
        var dados = JSON.stringify({ nome_bebida: nome_bebida, tipo_bebida: tipo_bebida, preco_bebida: preco_bebida });
        $.ajax({
            url: 'http://localhost:5000/incluir_bebidas',
            type: 'POST',
            dataType: 'json', 
            contentType: 'application/json',
            data: dados, 
            success: BebidaIncluida, 
            error: erroAoIncluir
        });
        function BebidaIncluida (retorno) {
            if (retorno.resultado == "ok") {
                alert("bebida incluída com sucesso!");
                $("#campoNomeBebida").val("");
                $("#campoTipoBebida").val("");
                $("#campoPreco").val("");
            } else {
                alert(retorno.resultado + ":" + retorno.detalhes);
            }            
        }
        function erroAoIncluir (retorno) {
            alert("ERRO: "+retorno.resultado + ":" + retorno.detalhes);
        }
    });

    $('#modalIncluirBebida').on('hide.bs.modal', function (e) {
        if (! $("#tabelaBebida").hasClass('invisible')) {
            exibir_bebidas();
        }
    });

    $(document).on("click", ".excluir_bebida", function() {
        var idBebida = $(this).attr("id");
    
        $.ajax({
          url: `http://localhost:5000/excluir_bebida/${idBebida}`,
          type: "DELETE",
          dataType: 'json',
          success: excluirBebida,
          error: erroAoExcluir
        });
    
        function excluirBebida(retorno) {
          if (retorno.resultado === "ok") {
            $(`#linha_${idBebida}`).fadeOut(1000, () => {
                alert("Bebida excluída com sucesso!")
            });
          } else {
            alert(`ERRO: ${retorno.resultado}: ${retorno.detalhes}`);
          }
        }
    
        function erroAoExcluir(retorno) {
          alert("Error: Search on back-end");
        }
      });
    

    mostrarConteudo("conteudoInicial");
});
