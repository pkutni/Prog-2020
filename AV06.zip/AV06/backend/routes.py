from config import *
from model import Bebida, Vendedor, Setor

@app.route("/")
def inicio():
    return 'Sistema de cadastro de bebidas. '+\
        '<a href="/listar_bebidas">Operação listar</a>'

@app.route("/listar_bebidas")
def listar_bebidas():
    bebidas = db.session.query(Bebida).all()
    bebidas_em_json = [ bebida.json() for bebida in bebidas ]
    resposta = jsonify(bebidas_em_json)
    resposta.headers.add("Access-Control-Allow-Origin", "*")
    return resposta

@app.route("/incluir_bebidas", methods = ["post"])
def incluir_bebidas():
    resposta = jsonify({"resultado": "ok", "detalhes": "ok"})
    dados = request.get_json()

    try: 
        nova_bebida = Bebida(**dados)
        db.session.add(nova_bebida)
        db.session.commit()
    except Exception as e: 
        resposta = jsonify({"resultado": "erro", "detalhes": str(e)})

    resposta.headers.add("Access-Control-Allow-Origin", "*") 
    return resposta

@app.route("/excluir_bebida/<int:id_bebida>", methods = ["delete"])
def excluir_bebida(id_bebida):
    resposta = jsonify({"resultado": "ok", "detalhes": "ok"})

    try: 
        Bebida.query.filter(Bebida.id == id_bebida).delete()
        db.session.commit()
    except Exception as e:
        resposta = jsonify({"resultado": "erro", "detalhes": str(e)})
        
    resposta.headers.add("Access-Control-Allow-Origin", "*") 
    return resposta

@app.route("/listar_vendedores")
def listar_vendedores():
    vendedores = db.session.query(Vendedor).all()
    vendedores_em_json = [ vendedor.json() for vendedor in vendedores ]
    resposta = jsonify(vendedores_em_json)
    resposta.headers.add("Access-Control-Allow-Origin", "*")
    return resposta

@app.route("/listar_setores")
def listar_setores():
    setores = db.session.query(Setor).all()
    setores_em_json = [ setor.json() for setor in setores ]
    resposta = jsonify(setores_em_json)
    resposta.headers.add("Access-Control-Allow-Origin", "*")
    return resposta