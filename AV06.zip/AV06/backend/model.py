
from config import *

class Bebida(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome_bebida = db.Column(db.String(254))
    tipo_bebida = db.Column(db.String(254))
    preco_bebida = db.Column(db.String(254))

    def __str__(self):
        return f"{self.id}. {self.nome_bebida}; {self.tipo_bebida}; {self.preco_bebida}"


    def json(self):
        return {
            "id": self.id,
            "nome_bebida": self.nome_bebida,
            "tipo_bebida": self.tipo_bebida,
            "preco_bebida": self.preco_bebida
        }


class Vendedor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(254))
    telefone = db.Column(db.String(254))

    def __str__(self):
        return f"{self.id}. {self.nome}; {self.telefone}"


    def json(self):
        return {
            "id": self.id,
            "nome": self.nome,
            "telefone": self.telefone
        }


class Setor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(254))
    funcionamento = db.Column(db.String(254))

    vendedor_id = db.Column(db.Integer, db.ForeignKey(Vendedor.id), nullable=False)
    mecanico = db.relationship("Vendedor")

    bebida_id = db.Column(db.Integer, db.ForeignKey(Bebida.id), nullable=False)
    bebida = db.relationship("Bebida")


    def __str__(self):
        return f"{self.id}. {self.nome}; {self.funcionamento}; {self.mecanico}; {self.bebida}"


    def json(self):
        return {
            "id": self.id,
            "nome": self.nome,
            "funcionamento": self.funcionamento,
            "vendedor_id": self.vendedor_id,
            "mecanico": self.mecanico.json(),
            "bebida_id": self.bebida_id,
            "bebida": self.bebida.json()
        }


if __name__ == "__main__":

    if os.path.exists(arquivobd):
        os.remove(arquivobd)

    db.create_all()

    bebida1 = Bebida(nome_bebida="Coca", tipo_bebida="Refrigerante", preco_bebida="R$6")
    db.session.add(bebida1)

    vendedor1 = Vendedor(nome="Robertinho", telefone="xx xxxx - xxxx")
    db.session.add(vendedor1)

    setor1 = Setor(nome="Setor de Refrigerante", funcionamento="7h - 17h",
                       bebida=bebida1, mecanico=vendedor1)

    db.session.add(setor1)


    db.session.commit()

    linha = '------------------------------------------------------------------'
    print(bebida1)
    print(bebida1.json())
    print(linha)
    print(vendedor1)
    print(vendedor1.json())
    print(linha)
    print(setor1)
    print(setor1.json())
