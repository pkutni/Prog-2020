Back end do trabalho de programacao II
