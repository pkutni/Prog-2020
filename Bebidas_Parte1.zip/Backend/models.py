from config import *

class Bebeida(db.Model):

    id = db.Column(db.Integer, primary_key=True)
    nome_bebida = db.Column(db.String(254))
    tipo_bebida = db.Column(db.String(254))
    preco_bebida = db.Column(db.String(254))
    #Método para expressar o time em formto texto
    
    def json(self):
        return {
            "id": self.id,
            "nome_bebida": self.nome_bebida,
            "tipo_bebida": self.tipo_bebida,
            "Preco_bebida": self.preco_bebida
        }

    def __str__(self):
        return str(self.id)+") "+ self.nome_bebida + ", " + self.tipo_bebida+ ", " + self.preco_bebida

    #Método que transforma a classe em json

#Criação dos testes    
if __name__ == "__main__":
    
    #Recria o arquivo
    if os.path.exists(arquivobd):
        os.remove(arquivobd)

    # criar bd
    db.create_all()

    #criação dos testes
    bebida1 = Bebeida(nome_bebida = "Coca-Cola", tipo_bebida = "Refrigerante", preco_bebida = "5,00")
    bebida2 = Bebeida(nome_bebida = "Kaiser", tipo_bebida = "Cerveja", preco_bebida = "1,99")
    bebida3 = Bebeida(nome_bebida = "Aqua10", tipo_bebida = "Água", preco_bebida = "0,89") 
    bebida4 = Bebeida(nome_bebida = "Jhony Red", tipo_bebida = "Destilado", preco_bebida = "77,00") 
    bebida5 = Bebeida(nome_bebida = "Corote", tipo_bebida = "Cachaça", preco_bebida = "4,60") 
       

    #add no bd
    db.session.add(bebida1)
    db.session.add(bebida2)
    db.session.add(bebida3)
    db.session.add(bebida4)
    db.session.add(bebida5)
    db.session.commit()

    #print em format json
    print(bebida1.json())
    print(bebida2.json())
    print(bebida3.json())
    print(bebida4.json())
    print(bebida5.json())
