$(function () {
    $("#list").click(function(){
        $.ajax({
            url: 'http://localhost:5000/listar_bebida',
            method: 'GET',
            dataType: 'json',
            success: listBebidas,
            error: function () {
                alert("ERROOOO, DÁ UMA OLHADA NO BACK-END CAMPEÃO");
            }
        });
    });

    function listBebidas(lista_bebida) {

        $('#tableBebida').empty();

        for (bebida of lista_bebida) {
            Linha_tabela = `<tr id="linha_${bebida.id}">
                        <td>${bebida.id}</td> 
                        <td>${bebida.nome_bebida}</td> 
                        <td>${bebida.tipo_bebida}</td> 
                        <td>${bebida.preco_bebida}</td>
                        <td><a href=# id="${bebida.id}" class="excluir_bebida">
                            <p class="badge badge-danger">Deletar</p> </a> </td>
                          </tr>`;

            $('#tableBebida').append(Linha_tabela);
        }
    }

    $("#btnInclude").click(function(){

        nameBebida = $("#nameBebida").val();
        nameTipoBebida = $("#nameTipoBebida").val();
        namePreco =  $("#namePreco").val();

        var dados = JSON.stringify({nome_bebida: nameBebida, tipo_bebida: nameTipoBebida, preco_bebida: namePreco});

        $.ajax({
            url: 'http://localhost:5000/adcionar_bebida',
            type: 'POST',
            contentType: 'application/json', 
            dataType: 'json',
            data: dados,
            success: adcionarBebida,
            error: erro_ao_Incluir_bebida
        });
        function adcionarBebida(resposta) {
            if (resposta.resultado == "ok") {

                alert("bebida cadastrada com sucesso. Recarregue a pagina para vê-lá");
                $("#nameBebida").val("");
                $("#nameTipoBebida").val("");
                $("#namePreco").val("");
            } else {
                alert("Erro ao incluirr");
            }
        }
        function erro_ao_Incluir_bebida(resposta) {
            alert("Não deu certo, verifique o beckend");
        }
    });
    
    $(document).on("click", ".excluir_bebida", function() {
        var IdBebida = $(this).attr("id");
    
        $.ajax({
          url: `http://localhost:5000/excluir_bebida/${IdBebida}`,
          type: "DELETE",
          dataType: 'json',
          success: excluirBebida,
          error: erroAoExcluir
        });
    
        function excluirBebida(retorno) {
          if (retorno.resultado === "ok") {
            $(`#linha_${IdBebida}`).fadeOut(1000, () => {
                alert("Bebida excluída com êxito!")
            });
          } else {
            alert(`Algo deu errado: ${retorno.resultado}: ${retorno.detalhes}`);
          }
        }
    
        function erroAoExcluir(retorno) {
          alert("Algo deu errado");
        }
      });

});
