from config import *
from models import Bebida

@app.route("/")
def inicar():
    return 'olá! Bem vindo ao codigo do Pedro H. Kutni. '+\
        '<a href="/listar_bebida">Ao clickar aqui será listada as bebidas já cadastradas no BD</a>'

@app.route("/listar_bebida")
def listar_bebida():
    bebida = db.session.query(Bebida).all()
    bebida_lista = [ bla.json() for bla in bebida ]
    lista = jsonify(bebida_lista)
    lista.headers.add("Access-Control-Allow-Origin", "*")
    return lista

@app.route("/adcionar_bebida", methods = ["POST"])
def adcionar_bebida():
    
    resposta = jsonify({"resultado": "ok", "detalhes": "ok"})
    dados = request.get_json()
    try:
        novo = Bebida(**dados)
        db.session.add(novo)
        db.session.commit()

    except Exception as e:
        resposta = jsonify({"resultado":"erro", "detalhes":str(e)})
    
    resposta.headers.add("Access-Control-Allow-Origin", "*")
    return resposta

@app.route("/excluir_bebida/<int:id_bebida>", methods = ["delete"])
def excluir_bebida(id_bebida):
    resposta = jsonify({"resultado": "ok", "detalhes": "ok"})

    try: 
        Bebida.query.filter(Bebida.id == id_bebida).delete()
        db.session.commit()
    except Exception as e:
        resposta = jsonify({"resultado": "erro", "detalhes": str(e)})
        
    resposta.headers.add("Access-Control-Allow-Origin", "*") 
    return resposta


app.run(debug=True)
