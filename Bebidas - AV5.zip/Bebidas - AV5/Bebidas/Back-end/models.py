from config import *

class Bebida(db.Model):

    id = db.Column(db.Integer, primary_key=True)
    nome_bebida = db.Column(db.String(254))
    tipo_bebida = db.Column(db.String(254))
    preco_bebida = db.Column(db.String(254))

    Bebida_setor = db.relationship("Setor",
                                     back_populates="setor_bebida")
    
    def json(self):
        return {
            "id": self.id,
            "nome_bebida": self.nome_bebida,
            "tipo_bebida": self.tipo_bebida,
            "preco_bebida": self.preco_bebida
        }

    def __str__(self):
        return str(self.id)+") "+ self.nome_bebida + ", " + self.tipo_bebida+ ", " + self.preco_bebida

class Vendedor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(254))
    telefone = db.Column(db.String(254))

    Vendedor_setor = db.relationship("Setor",
                                     back_populates="setor_vendedor")

    
    def __str__(self):
        return f"{self.id}) {self.nome}; {self.telefone}"


    def json(self):
        return {
            "id": self.id,
            "nome": self.nome,
            "telefone": self.telefone
        }

class Setor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    capacidade = db.Column(db.Integer)
    Localizcao = db.Column(db.String(254))
    responsavel = db.Column(db.String(254))

    vendedor_id = db.Column(db.ForeignKey(Vendedor.id), nullable=False)
    setor_vendedor = db.relationship("Vendedor", back_populates="Vendedor_setor")

    bebida_id = db.Column(db.ForeignKey(Bebida.id), nullable=False)
    setor_bebida = db.relationship("Bebida", back_populates="Bebida_setor")


    def __str__(self):
        return f"{self.id}) {self.capacidade}; {self.Localizcao}; {self.responsavel};\n"+\
               f"{self.setor_vendedor};\n" +\
               f"{self.setor_bebida}"


    def json(self):
        return {
            "id": self.id,
            "capacidade": self.capacidade,
            "Localizcao": self.Localizcao,
            "responsavel": self.responsavel,
            "vendedor_id": self.vendedor_id,
            "setor_vendedor": self.setor_vendedor,
            "bebida_id": self.bebida_id,
            "setor_bebida": self.setor_bebida
        }


if __name__ == "__main__":
    
    if os.path.exists(arquivobd):
        os.remove(arquivobd)

    db.create_all()

    bebida1 = Bebida(nome_bebida = "Coca-Cola", tipo_bebida = "Refrigerante", preco_bebida = "R$5,00")
    db.session.add(bebida1)

    vendedor1 = Vendedor(nome = "Leozinho", telefone = "47 9999-9999")

    setor1 = Setor(capacidade = 3, Localizcao = "Bloco B", responsavel = "Refrigerante", setor_vendedor = vendedor1, setor_bebida = bebida1)
   
    db.session.commit()

    print(bebida1.json())
    print(vendedor1.json())
    print(setor1.json())

   

"""
 bebida2 = Bebida(nome_bebida = "Kaiser", tipo_bebida = "Cerveja", preco_bebida = "R$1,99")
    bebida3 = Bebida(nome_bebida = "Aqua10", tipo_bebida = "Água", preco_bebida = "R$0,89") 
    bebida4 = Bebida(nome_bebida = "Jhony Red", tipo_bebida = "Destilado", preco_bebida = "R$77,00") 
    bebida5 = Bebida(nome_bebida = "Corote", tipo_bebida = "Cachaça", preco_bebida = "R$4,60") 
     db.session.add(bebida2)
    db.session.add(bebida3)
    db.session.add(bebida4)
    db.session.add(bebida5)
     print(bebida2.json())
    print(bebida3.json())
    print(bebida4.json())
    print(bebida5.json())
"""