from config import *

class Bebeida(db.Model):

    id = db.Column(db.Integer, primary_key=True)
    nome_bebida = db.Column(db.String(254))
    tipo_bebida = db.Column(db.String(254))
    preco_bebida = db.Column(db.String(254))
    
    def json(self):
        return {
            "id": self.id,
            "nome_bebida": self.nome_bebida,
            "tipo_bebida": self.tipo_bebida,
            "preco_bebida": self.preco_bebida
        }

    def __str__(self):
        return str(self.id)+") "+ self.nome_bebida + ", " + self.tipo_bebida+ ", " + self.preco_bebida


if __name__ == "__main__":
    
    if os.path.exists(arquivobd):
        os.remove(arquivobd)

    db.create_all()

    bebida1 = Bebeida(nome_bebida = "Coca-Cola", tipo_bebida = "Refrigerante", preco_bebida = "R$5,00")
    bebida2 = Bebeida(nome_bebida = "Kaiser", tipo_bebida = "Cerveja", preco_bebida = "R$1,99")
    bebida3 = Bebeida(nome_bebida = "Aqua10", tipo_bebida = "Água", preco_bebida = "R$0,89") 
    bebida4 = Bebeida(nome_bebida = "Jhony Red", tipo_bebida = "Destilado", preco_bebida = "R$77,00") 
    bebida5 = Bebeida(nome_bebida = "Corote", tipo_bebida = "Cachaça", preco_bebida = "R$4,60") 
       

    db.session.add(bebida1)
    db.session.add(bebida2)
    db.session.add(bebida3)
    db.session.add(bebida4)
    db.session.add(bebida5)
    db.session.commit()

    print(bebida1.json())
    print(bebida2.json())
    print(bebida3.json())
    print(bebida4.json())
    print(bebida5.json())
