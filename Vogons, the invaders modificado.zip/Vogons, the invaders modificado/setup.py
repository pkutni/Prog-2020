from distutils.core import setup

setup(name='Vogons, the invaders',
      version='1.0',
      description='Jogo feito na linguagem python',
      author='Gustavo, Josef, Pedro e vinicius',
      author_email='projeto.jogao@gmail.com',
     )