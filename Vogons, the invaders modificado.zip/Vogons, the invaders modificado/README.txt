O jogo é implementado na linguagem Python, utilizando a biblioteca Arcade.O estilo do jogo é parecido com um jogo de arcade, que contará com uma nave principal que tentará destruir seus inimigos e enfrentará um chefão à cada certa quantidade de tempo. 

O objetivo do trabalho é fazer o jogo ficar o mais parecido com um jogo de fliperama possível, com o intuito de tentar valorizar mais os jogos das décadas passadas. O jogo conta com um ranking interno e um sistema de hordas dos inimigos, um sistema de vidas para a nave principal (do jogador), etc.

Com o fim da codificação os resultados obtidos foram além do esperado, ainda mais para pessoas leigas na área. Execute o jogo para ver o resultado final

