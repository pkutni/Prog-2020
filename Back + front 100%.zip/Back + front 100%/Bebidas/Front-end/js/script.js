$(function () {
    $.ajax({
        url: 'http://localhost:5000/listar_bebida',
        method: 'GET',
        dataType: 'json',
        success: listBebidas,
        error: function () {
            alert("ERROOOO, DÁ UMA OLHADA NO BACK-END CAMPEÃO");
        }
    });

    function listBebidas(lista_bebida) {
        for (bebida of lista_bebida) {
            Linha_tabela = `<tr> 
                        <td>${bebida.nome_bebida}</td> 
                        <td>${bebida.tipo_bebida}</td> 
                        <td>${bebida.preco_bebida}</td> 
                      </tr>`;

            $('#tableBebida').append(Linha_tabela);
        }
    }
});